/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package yaaaay.projeto.individual.s1;

import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;

/**
 *
 * @author teteg
 */
public class JogoDeCartas {

    ElementosGraficos element = new ElementosGraficos();
    Scanner leitor = new Scanner(System.in);

    Integer mudaDecoracao(Integer decoracao) {
        element.exibeDecoracao(decoracao);
        System.out.println("Digite o número da linha de decoracao desejada");
        System.out.println("""
                               
            1- .-.-.-.-.-.-.-.-.-.
            2- •*´¨`*•.¸¸.•*´¨`*•.¸¸.•*
            3- ___° ° °___»«___° ° °___
            4- •°•°•°•°•°•°•°•°•°•°•°•°•°•°•°
            5- ~~••~~••~~••~~••~~••~~••~~••~~
            6- ¤ = ~~ ~ * ~ ~~ = ¤
            7- __°__°__°__°__°__°__°__°""");
        element.exibeDecoracao(decoracao);
        Integer valDecoracao = leitor.nextInt();

        if (valDecoracao >= 1 && valDecoracao <= 7) {

            element.exibeDecoracao(valDecoracao);
            System.out.println("Linha de decoracao alterada com sucesso!");
            element.exibeDecoracao(valDecoracao);

            return valDecoracao;
        } else {
            System.out.println("Opção inválida, tente novamente :(");
            return decoracao;
        }
    }
    
    Integer sortearCarta(){
        Integer sorteio = ThreadLocalRandom.current().nextInt(1,14);
        
        String valorCarta = "";
        Integer valorJogo = 0;
        
        switch (sorteio){
            case 11:
                valorCarta = "J";
                valorJogo = 10;
                break;
            case 12:
                valorCarta = "Q";
                valorJogo = 10;
                break;
            case 13:
                valorCarta = "K";
                valorJogo = 10;
                break;
            default:
                valorCarta = String.format("%d",sorteio);
                valorJogo = sorteio;
                break;
        }
        
        element.exibeCarta(valorCarta);
        
        return valorJogo;
    }
    
    Integer acabarJogo(Integer soma, Integer record, Integer decoracao){
        
        Integer pontuacao = 0;
        
        
        element.exibeDecoracao(decoracao);
        if(soma <= 5){
            System.out.println("Tem que praticar mais :(");
            pontuacao = 50;
        } else if(soma <= 10){
            System.out.println("Não tenha medo de arriscar!");
            pontuacao = 100;
        } else if(soma <= 15){
            System.out.println("Ta pegando o jeito!!!");
            pontuacao = 150;
        } else if (soma <= 20){
            System.out.println("Nooooooossa essa foi quase!");
            pontuacao = 200;
        } else if (soma == 21){
            System.out.println("YAAAAAAAAAAAAAAAAAAAAAAY");
            pontuacao = 500;
        } else {
            System.out.println("Vai com calma colega");
            pontuacao = 10;
        }
        
        System.out.println("Sua pontuação final é: "+ pontuacao);
        element.exibeDecoracao(decoracao);
        
        if (pontuacao > record){
            record = pontuacao;
            System.out.println("É um novo record!");
        }
        
        return record;
    }
}
