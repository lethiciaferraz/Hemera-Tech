/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package yaaaay.projeto.individual.s1;

/**
 *
 * @author teteg
 */
public class ElementosGraficos {
    void exibeDecoracao(Integer decoracao){
        switch (decoracao) {
            case 1:
                System.out.println("\n.-.-.-.-.-.-.-.-.-.\n");
                break;
            case 2:
                System.out.println("\n•*´¨`*•.¸¸.•*´¨`*•.¸¸.•*\n");
                break;
            case 3:
                System.out.println("\n___° ° °___»«___° ° °___\n");
                break;
            case 4:
                System.out.println("\n•°•°•°•°•°•°•°•°•°•°•°•°•°•°•°\n");
                break;
            case 5:
                System.out.println("\n~~••~~••~~••~~••~~••~~••~~••~~\n");
                break;
            case 6:
                System.out.println("\n¤ = ~~ ~ * ~ ~~ = ¤\n");
                break;
            case 7:
                System.out.println("\n__°__°__°__°__°__°__°__•\n");
                break;
        }
    }
    
    void exibeCarta(String valorCarta ){
        System.out.println(String.format("""
                                         _______
                                        | _____ |
                                        ||     ||
                                        ||  %s  ||
                                        ||_____||
                                        |_______| """, valorCarta));
    }
}
    
