/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package yaaaay.projeto.individual.s1;

import java.util.Scanner;

/**
 *
 * @author teteg
 */
public class TesteJogoDeCartas {
    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
        JogoDeCartas jogo = new JogoDeCartas();
        ElementosGraficos element = new ElementosGraficos();
        
        Integer escolhido = -1;
        Integer decoracao = 1;
        Integer record =0;
        
        while(escolhido != 5){
            element.exibeDecoracao(decoracao);
            System.out.println("VAMOS JOGAR 21");
            element.exibeDecoracao(decoracao);
            System.out.println("Digite o número da opção desejada");
            element.exibeDecoracao(decoracao);
            System.out.println("""
            1- Regras
            2- Records
            3- Alterar decoração
            4- >>Jogar<<
            5- Sair           """);
            element.exibeDecoracao(decoracao);
            escolhido = leitor.nextInt();
            
            switch (escolhido){
                case 1:
                    Integer somaTeste = 0;
                    
                    element.exibeDecoracao(decoracao);
                    System.out.println("No início do jogo você recebe suas cartas como estas:");
                    somaTeste += jogo.sortearCarta();
                    somaTeste += jogo.sortearCarta();
                    System.out.println("E também a soma delas, que no caso é: "+ somaTeste);
                    System.out.println("Seu objetivo é ir adicionando cartas (ou não) para chegar o mais próximo o possível de 21 pontos, mas sem estourar esse limite");
                    System.out.println("Ao fim, será exibida sua pontuação baseado da quantidade de pontos somados \n Bom jogo :)");
                    
                    break;
                case 2:
                    element.exibeDecoracao(decoracao);
                    System.out.println("Seu record atual é: " + record);
                    
                    if(record == 500){
                        System.out.println("Esse é o record máximo!");
                    }
                    element.exibeDecoracao(decoracao);
                    
                    break;
                case 3:
                    decoracao = jogo.mudaDecoracao(decoracao);
                    break;
                case 4:
                    Integer soma = 0;
                    
                    soma += jogo.sortearCarta();
                    soma += jogo.sortearCarta();
                    
                    element.exibeDecoracao(decoracao);
                    System.out.println("A soma de suas cartas é: " + soma);
                    element.exibeDecoracao(decoracao);
                    
                    int escolha = -1;
                    while(soma < 21 && escolha != 2){
                        element.exibeDecoracao(decoracao);
                        System.out.println("Deseja puxar mais uma carta?'"
                                + "\n 1- Sim"
                                + "\n 2- Não");
                        element.exibeDecoracao(decoracao);
                        
                        escolha = leitor.nextInt();
                        
                        if (escolha == 1){
                            soma += jogo.sortearCarta();
                            element.exibeDecoracao(decoracao);
                            System.out.println("A soma de suas cartas é: " + soma);
                            element.exibeDecoracao(decoracao);
                        }
                    }
                    
                    record = jogo.acabarJogo(soma, record, decoracao);
                    
                    break;
                case 5:
                    System.out.println("Bye Bye colega");
                    break;
                default:
                    System.out.println("Opição inválida, tente novamente");
            }
        }
    }
}
