package dennys.projeto.individual.isaias.resende;

import java.util.Scanner;

/**
 *
 * @author DenilsonReis
 */
public class BatalhaPokemon {

    public static void main(String[] args) {

        Scanner leitor = new Scanner(System.in);

        int simplesMenu = 1;
        int menuSimplesEscolhaPokemon = 1;

        int pokemonFogo = 0;
        int pokemonPlanta = 0;
        int pokemonAgua = 0;

        Integer externoEscolhaPokemonUsuario = 0;

        int contadorSimplesMenu = 0;

        while (contadorSimplesMenu < simplesMenu) {

            System.out.println(
                    "----------------------------------------------------"
                    + "Digite a opção que voce deseja: \n"
                    + "1 - Esolha seu pokemon \n"
                    + "2 - Batalha pokemon \n"
                    + "3 - Lista pokemon mias votados\n"
                    + "4 - Sair do jogo \n"
                    + "----------------------------------------------------"
            );
            Integer escolhaMenuUsuario = leitor.nextInt();

            switch (escolhaMenuUsuario) {
                case 1:

                    int contadorSimplesEscolhaPokemon = 0;

                    while (contadorSimplesEscolhaPokemon < menuSimplesEscolhaPokemon) {

                        System.out.println(
                                "----------------------------------------------------"
                                + "Esolha o tipo de pokemon escolhido: \n"
                                + "1 - Fogo \n"
                                + "2 - Planta \n"
                                + "3 - Agua \n"
                                + "----------------------------------------------------");
                        Integer escolhaPokemonUsuario = leitor.nextInt();
                        externoEscolhaPokemonUsuario = escolhaPokemonUsuario;

                        switch (escolhaPokemonUsuario) {

                            case 1:
                                pokemonFogo++;
                                System.out.println("Voce escolheu um pokemon tipo fogo");
                                menuSimplesEscolhaPokemon--;
                                break;

                            case 2:
                                pokemonPlanta++;
                                System.out.println("Voce escolheu um pokemon tipo planta");
                                menuSimplesEscolhaPokemon--;
                                break;

                            case 3:
                                pokemonAgua++;
                                System.out.println("Voce escolheu um pokemon tipo agua");
                                menuSimplesEscolhaPokemon--;
                                break;

                            default:
                                System.out.println("Opção invalida, tente novamente");
                                menuSimplesEscolhaPokemon++;
                        }

                    }
                    simplesMenu++;
                    break;

                case 2:
                    if (externoEscolhaPokemonUsuario == 1) {
                        System.out.println("Seu pokemon ganha da planta e perde para agua");
                    } else if (externoEscolhaPokemonUsuario == 2) {
                        System.out.println("Seu pokemon ganha da agua e perde para fogo");
                    } else {
                        System.out.println("Seu pokemon ganha da fogo e perde para planta");
                    }

                    simplesMenu++;
                    break;

                case 3:

                    System.out.println(String.format(
                            "Lista de pokemons mais escolhidos: \n Fogo - %d  \n Planta - %d \n Agua - %d", pokemonFogo, pokemonPlanta, pokemonAgua));

                    simplesMenu++;
                    break;

                case 4:
                    simplesMenu--;
                    simplesMenu--;
                    break;

            }

        }

    }
}
