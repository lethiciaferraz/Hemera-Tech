
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author lethi
 */
public class TesteCalculadoraAgua {

    public static void main(String[] args) {

        Scanner leitor = new Scanner(System.in);
        Integer menuAgua = 0;
        CalculadoraAgua calc = new CalculadoraAgua();

        do {
            System.out.println( "\nBem vindo a sua calculadora pessoal de água \n"+
                           "Escolha uma opção:\n" +
                           "1- Calcular quantos litros devo beber por dia\n" +
                           "2- Saber o quão perto estou da meta diária de consumo de água\n" +
                           "3- Ter um feedback completo do meu consumo de água\n" +
                           "4- Sair\n");
            menuAgua = leitor.nextInt();

            switch (menuAgua) {
                case 1:
                    System.out.println("Insira seu peso:");
                    Double peso = leitor.nextDouble();
                    calc.calcularAguaPeso(peso);

                    break;
                case 2:
                    System.out.println("Insira em mililitros (exemplo: x,xxx)a quantidade de água que ja ingeriu hoje:");
                    Double aguaDigitada = leitor.nextDouble();
                    calc.saberMetaDia(aguaDigitada);
                    break;
                case 3:
                    System.out.println("Insira seu peso:");
                    peso = leitor.nextDouble();
                    System.out.println("Insira em mililitros (exemplo: x,xxx)a quantidade de água que ja ingeriu hoje:");
                    aguaDigitada = leitor.nextDouble();
                    calc.receberFeedback(peso, aguaDigitada);
                    calc.saberMetaDia(aguaDigitada);
                    break;
                case 4:
                    System.out.println("Tchau tchau!");
                    break;
                default:
                    System.out.println("Opção inválida, tente novamente");
            }

        } while (menuAgua != 4);

    }

}
