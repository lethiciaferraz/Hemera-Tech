/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author lethi
 */
public class CalculadoraAgua {

    void calcularAguaPeso(Double peso) {
        Double calculo1 = peso * 0.035;

        String frase = String.format("Você deve beber %.2f litros de água por dia.", calculo1);
        System.out.println(frase);
    }

    void saberMetaDia(Double aguaDigitada) {

        if (aguaDigitada <= 0.500) {
            System.out.println("Você está longe da meta :( , vá beber água!");
        } else if (aguaDigitada <= 0.900) {
            System.out.println("Está no caminho certo, continue assim.");
        } else if (aguaDigitada <= 1.500) {
            System.out.println("Você está perto da meta, continue bebendo água!");
        } else if (aguaDigitada == 2.000) {
            System.out.println( "Parabéns, você atingiu a meta média diária. Mantenha-se hidratado(a) :)");
        } else {
            System.out.println("Wow, você ultrapassou a meta, você é quase um peixinho!");
        }
    }
    
    void receberFeedback (Double peso, Double aguaDigitada){
        Double calculo1 = peso * 0.035;

        String frase1 = String.format("Baseado no seu peso você deve beber %.2f litros de água por dia.", calculo1);
        System.out.println(frase1);
        
        Double calculo2 =  calculo1 - aguaDigitada;
        
        String frase2 = String.format("Você ingeriu %.3f de água, você precisa consumir mais %.3f para atingir sua meta diária." ,aguaDigitada, calculo2);
        System.out.println(frase2);
        
        
        
    }
}
