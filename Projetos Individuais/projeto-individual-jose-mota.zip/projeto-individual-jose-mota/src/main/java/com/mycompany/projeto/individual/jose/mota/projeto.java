/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projeto.individual.jose.mota;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author jgmat
 */
public class projeto {
    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
        metodos metodo = new metodos();
        Integer opcao;
        Integer forca = 0;

        
        do {
            System.out.println("--------------------");
            System.out.println("--------------------");
            System.out.println("Mota`s Land RPG");
            System.out.println("--------------------");
            System.out.println("Bem vindo ao mundo de Mota`s Land");
            System.out.println("Siga todos os passos para realizar uma batalha");
            System.out.println("----------------------");
            System.out.println("1 - Sorteie seu poder de força!");
            System.out.println("2 - Veja qual o seu potencial!");
            System.out.println("3 - Qual a sua identificação de classe!");
            System.out.println("4 - Batalhar!!");
            System.out.println("0 - Sair");
            System.out.println("--------------------");
            opcao = leitor.nextInt();
            
            
            switch (opcao) {
                case 1:
                    // Professor(a), não imaginei nenhum outro tipo de conta no meu contexto, no caso tem muito mais conta no método de batalha, desculpe hahahaha
                    Integer valorForca = metodo.calculoForca(forca);
                    forca = valorForca;
                    System.out.println("Seu poder de força é de " + forca);
                    break;
                    
                case 2:
                    metodo.potencial(forca);
                    
                    break;
                case 3:
                    metodo.proximidadeClasse();
                    break;
                            
                case 4:
                    metodo.batalha(forca);
                    break;
                
                case 0:
                    System.out.println("Até logo!");
                    break;
                default:
                    System.out.println("Opção inválida, tente novamente");
                    break;
            }
        } while (opcao != 0);
        
    }
}
