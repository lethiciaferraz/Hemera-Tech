/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projeto.individual.jose.mota;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author jgmat
 */
public class metodos {
   
    Random sorteio = new Random();
    void batalha(Integer forca){
        Integer vidaPropria = 100;
        Integer vidaInimigo = 100;
        Integer forcaInimigo = sorteio.nextInt(35)+1;
        System.out.println("---------------------");
        System.out.println("Agora iremos testar o seu real potencial em uma batalha até a morte!");
        System.out.println("---------------------");
        Integer opcao;
        Scanner leitor = new Scanner(System.in);
        do{
            System.out.println("Sua vida:"+ vidaPropria + " Vida adversário " + vidaInimigo);
            System.out.println("Sua força: " + forca + "Força do inimigo: " + forcaInimigo);
            System.out.println("1 - Atacar usando o seu poder de força!");
            System.out.println("2 - Curar 10 pontos de vida passar a rodada!");
            opcao = leitor.nextInt();
         
          switch(opcao){
              case 1 :
                  System.out.println("você ataca seu inimigo com um golpe brutal!");
                  vidaInimigo = vidaInimigo -= forca;
                  System.out.println("Seu inimigo está com " + vidaInimigo + " de vida");
                  System.out.println("Ele te desfere um golpe feroz");
                  vidaPropria = vidaPropria - forcaInimigo ;
                  System.out.println("Seus pontos de vida são: " + vidaPropria);
                 
                 
                  break;
                  
              case 2:
                  System.out.println("Você se cura! Ganhando 10 pontos de vida");
                  vidaPropria += 10;
                  Integer sorteioAtaqueOpt = sorteio.nextInt(4)+1;
                  if(sorteioAtaqueOpt == 3){
                      System.out.println("Enquanto você se curava o inimigo obteve um ataque de oportunidade!");
                      Integer sorteioDanoAtq = sorteio.nextInt(15)+1;
                      vidaPropria -= sorteioDanoAtq;
                      System.out.println("Ele te deu " + sorteioDanoAtq + " de dano");
                  }
                  System.out.println("Seus pontos de vida são: " + vidaPropria);
                  break;
              default:
                  System.out.println("Digite uma opção válida"); 
                  break;
          }  
        }while(vidaInimigo > 0 && vidaPropria > 0);
           if(vidaPropria <= 0 ){
                      System.out.println("Você perdeu");
                      
            }
            if(vidaInimigo <= 0 ){
                      System.out.println("Você Ganhou!");
                      
                      
            }
    }
    
    
    Integer calculoForca(Integer forca) {
        Integer forcaSorteada = sorteio.nextInt(20) + 1;
        Integer calculoForca = forcaSorteada * 2;
        return calculoForca;
        
    }
    
    
    void potencial(Integer forca) {
        if(forca <= 5){
            System.out.println("Você não apresenta muito potencial, irá viver a vida de camponês provavelmente");
        }else if(forca <= 15){
            System.out.println("Se tiver sorte conseguirá virar um guerreiro mediano");
        }else if(forca <= 30){
            System.out.println("parece que você tem um grande caminho a trilhar na vida de guerreiro!");
        }else{
            System.out.println("Com certeza você irá se torna um grande REI!");
        }
    }
    
    
    void proximidadeClasse(){
        Scanner leitor = new Scanner(System.in);
        Integer opcao = 0;
        do{
            System.out.println("----------------------------------");
            System.out.println("Responda como você agiria de acordo a seguinte situação...");
            System.out.println("É tarde da noite e você se depara com ladrões roubando ouro de pessoas inocentes");
            System.out.println("o que você faz?");
            System.out.println("1 - Corre e combate os ladrões com toda sua força");
            System.out.println("2 - Usa a escuridão a seu favor e derruba um por um com sutileza");
            System.out.println("3 - Usa seu conhecimento de artes antigas e atinge os ladrões com uma poderosa magia");
            opcao = leitor.nextInt();
            if(opcao == 1){
                System.out.println("Você tem inclinação a ser um forte GUERREIRO");
            }
            if(opcao == 2){
                System.out.println("Você tem inclinação a sombras e a se tornar um grande LADINO");
            }
            if(opcao == 3){
                System.out.println("você tem inclinação para ser um poderoso MAGO");
            }
            if(opcao > 3){
                System.out.println("Digite uma opção válida");
            }
        }while(opcao > 3);
    }
}
