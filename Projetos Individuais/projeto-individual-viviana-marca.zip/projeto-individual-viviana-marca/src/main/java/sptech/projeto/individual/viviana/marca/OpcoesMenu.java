/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sptech.projeto.individual.viviana.marca;

/**
 *
 * @author VivianaMarca
 */
public class OpcoesMenu {

    Integer calculoIdade(Integer anoLancamento, Integer anoNascimento) {
        return anoLancamento - anoNascimento;
    }

    Integer calcularPontuacao(String resposta1, Integer resposta2, String resposta3, String resposta4, String resposta5){
       Integer pontuacao = 0;
        
        if(resposta1.equalsIgnoreCase("Avril Ramona Lavigne")){
            pontuacao++;
        }
        
        if(resposta2.equals(1984)){
            pontuacao++;
        }
        if(resposta3.equalsIgnoreCase("Libra")){
            pontuacao++;
        }
        if(resposta4.equalsIgnoreCase("Black Star")){
            pontuacao++;
        }
        if(resposta5.equalsIgnoreCase("Abbey Dawn")){
            pontuacao++;
        }
        return pontuacao;
    }
    
    void exibirResultado(Integer pontuacao){
        if(pontuacao.equals(5)) {
            System.out.println("Pontuação máxima\nVocê é realmente um Little Black Star!!");
        }else if(pontuacao > 2){
            System.out.println("Pontuação na média!\n Você sabe muito da Avril!!");
        }else{
            System.out.println("Pontuação baixa :(\nVamos pesquisar mais sobre a Avril?");
        }
    }
 
    void exibirTrecho(Integer numeroAleatorio) {

        switch (numeroAleatorio) {
            case 1:
                System.out.println("Todo mundo se machuca algum dia\n"
                        + "E tudo bem ter medo\n"
                        + "Todo mundo se machuca\n"
                        + "Todo mundo grita\n"
                        + "Todo mundo se sente desse jeito\n"
                        + "E tudo bem - Everybody Hurts");
                break;
            case 2:
                System.out.println("Você me pegou pela mão e me levou pra casa, eu sei\n"
                        + "Por que você me deu aquele beijo?\n"
                        + "Foi algo meio assim e me fez dizer, uh-oh\n"
                        + "Você secou minhas lágrimas, tirou todos os meus medos\n"
                        + "Por que você teve que ir?\n"
                        + "Acho que não foi suficiente ganhar um pouco do meu amor- Don't Tell Me");
                break;
            case 3:
                System.out.println("Às vezes eu fico tão estranha\n"
                        + "Eu até assusto a mim mesma\n"
                        + "Eu dou risada até dormir\n"
                        + "É a minha canção de ninar - Anything But Ordinary");
                break;

            case 4:
                System.out.println("Abra suas asas, pelo universo\n"
                        + "É a sua hora, sua hora de brilhar\n"
                        + "Existe uma luz dentro de todos nós\n"
                        + "Logo, você vai ver que é sua hora de voar - Fly");
                break;
            case 5:
                System.out.println("Você não precisa sempre fazer tudo certo\n"
                        + "Defenda-se\n"
                        + "E arranje uma briga\n"
                        + "Ande por aí com suas mãos para o ar\n"
                        + "Como se não ligasse - Freak Out");
                break;
            case 6:
                System.out.println("Essa é a parte onde eu começo a roer minhas unhas\n"
                        + "E limpar meu quarto quando tudo falha\n"
                        + "Acho que está na hora de me esvaziar (hora de esvaziar)\n"
                        + "Esse ponto de vista está ficando velho - He Wasn't");
                break;
            case 7:
                System.out.println("Escute quando eu digo, quando digo que acredito\n"
                        + "Nada irá mudar, nada irá mudar o destino\n"
                        + "O que quer que seja nós resolveremos perfeitamente - Keep Holding On");
                break;
            case 8:
                System.out.println("Não posso evitar se viajo numa fantasia\n"
                        + "Meu olhos acabam virando para o outro lado\n"
                        + "Eu posso me desligar e sonhar acordada\n"
                        + "Nessa cabeça, meus pensamentos são profundos\n"
                        + "Mas às vezes não consigo nem falar\n"
                        + "Será que alguém poderia ser e não fingir?\n"
                        + "Estou desligada de novo em meu mundo - My World");
                break;
            case 9:
                System.out.println("Me dê um pouco de tempo\n"
                        + "Me deixe sozinha um pouquinho\n"
                        + "Talvez não seja tarde demais - Tomorrow");
                break;
            case 10:
                System.out.println("Quem sabe o que pode acontecer?\n"
                        + "Faça o que você faz, apenas continue rindo\n"
                        + "Uma coisa é verdade\n"
                        + "Há sempre um novo dia\n"
                        + "Eu vou viver hoje como se fosse meu último dia - Who Knows");
                break;
        }
        
    }
    
    void exibirLinha(){
        System.out.println("\n------------------------------------------------------------------------------------------------------------");
    }

}
