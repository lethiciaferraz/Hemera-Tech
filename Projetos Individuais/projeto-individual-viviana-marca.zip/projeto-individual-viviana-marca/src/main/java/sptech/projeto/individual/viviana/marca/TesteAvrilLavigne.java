/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sptech.projeto.individual.viviana.marca;

import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;

/**
 *
 * @author VivianaMarca
 */
public class TesteAvrilLavigne {

    public static void main(String[] args) {

        OpcoesMenu opcao = new OpcoesMenu();

        Scanner leitor = new Scanner(System.in);
        

        System.out.println("---------------------------------------------------- AVRIL LAVIGNE ------------------------------------------------------------- \n"
                + "Cantora e compositora canadense nascida no dia 27 de setembro de 1984, intitulada por muitos como a Rainha do Pop Punk");
        opcao.exibirLinha();

        Integer opcaoDigitada;

        do {
            System.out.println("\nO que você quer ver?\n1-Quantos anos você tinha quando Avril Lavigne lançou seu primeiro albúm?"
                    + "\n2-Você sabe tudo sobre a Avril? \n"
                    + "3-Sorteio de trechos de Músicas\n0-Sair");

            opcaoDigitada = leitor.nextInt();

            switch (opcaoDigitada) {
                case 1:
                    System.out.println("Digite o ano que você nasceu:");
                    Integer anoDigitado = leitor.nextInt();
                    Integer respostaCalculo = opcao.calculoIdade(2002, anoDigitado);

                    if (respostaCalculo > 0) {
                        System.out.format("Você tinha %d anos quando a Avril Lavigne lançou o albúm Let Go", respostaCalculo);
                    } else if (respostaCalculo.equals(0)) {
                        System.out.println("O albúm Let Go foi lançado em 2002, justamente no ano que você nasceu!!");
                    } else {
                        System.out.format("O albúm Let go foi lançado %d anos antes do ano do seu nascimento", respostaCalculo * -1);
                    }
                    break;

                case 2:
                    leitor.nextLine();    
                    
                    opcao.exibirLinha();
                    System.out.println("Teste você sabe tudo da loirinha?\nNome completo: ");
                    String nomeRespostaDigitada = leitor.nextLine();
                    opcao.exibirLinha();

                    System.out.println("Ano de nascimento: ");
                    Integer anoRespostaDigitado = leitor.nextInt();
                    opcao.exibirLinha();

                    leitor.nextLine();    
                    System.out.println("Signo: ");
                    String signoRespostaDigitado = leitor.nextLine();
                    opcao.exibirLinha();
                    
                    System.out.println("Nome a primeira fragância: ");
                    String fraganciaRespostaDigitada = leitor.nextLine();
                    opcao.exibirLinha();

                    System.out.println("Nome da linha roupa: ");
                    String linhaRoupaRespostaDigitada = leitor.nextLine();
                    opcao.exibirLinha();

                    Integer pontuacaoFeita = opcao.calcularPontuacao(nomeRespostaDigitada, anoRespostaDigitado, signoRespostaDigitado,
                            fraganciaRespostaDigitada, linhaRoupaRespostaDigitada);

                    System.out.format("Respostas certas: %d\n", pontuacaoFeita);

                    opcao.exibirResultado(pontuacaoFeita);

                    break;

                case 3:
                    Integer numeroAleatorio
                            = ThreadLocalRandom.current().nextInt(1, 11);
                    System.out.println("------------------------------------------Trecho sorteado---------------------------------------------------");
                    opcao.exibirTrecho(numeroAleatorio);
                    System.out.println("---------------------------------------------------------------------------------------------------------");
                    break;

                case 0:
                    System.out.println("Até a próxima então");
                    break;

                default:
                    System.out.println("Digite um número válido!");
            }

        } while (opcaoDigitada != 0);
    }
}
